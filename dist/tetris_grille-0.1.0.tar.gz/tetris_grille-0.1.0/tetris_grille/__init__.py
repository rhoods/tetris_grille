from .tetris_grille import menuJeu as run_game

__all__ = [
    "run_game",
]


