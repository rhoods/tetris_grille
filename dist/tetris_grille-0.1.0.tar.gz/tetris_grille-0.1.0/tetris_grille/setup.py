from cx_Freeze import setup, Executable

base = None    

executables = [Executable("tetris_grille.py", base=base)]

packages = ["idna", "os", "pygame", "numpy", "copy", "random", "math", "cmath", "ast", "symbol", "winreg"]
files = ["classe", "font", "image", "sounds", "record", "env"]
options = {
    'build_exe': {    
        'packages':packages,
        'include_files': files,
    },
}

setup(
    name = "tetris_grille",
    options = options,
    version = "1.0",
    description = '<any description>',
    executables = executables
)